//
//  ViewController.swift
//  search
//
//  Created by Yogesh Patel on 26/08/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import UIKit

struct DataModel{
    var fname:String = ""
    var lname:String = ""
}

class ViewController: UIViewController, UISearchBarDelegate, UISearchControllerDelegate {

    @IBOutlet var tableView: UITableView!
    var arrData = [DataModel]()
    let searchController = UISearchController(searchResultsController: nil)
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        searchBarSetup()
        DataModelSetUP()
    }
    private func DataModelSetUP(){
        arrData = [
            DataModel(fname: "Yogesh", lname: "Patel"),
            DataModel(fname: "Hemal", lname: "Patel"),
            DataModel(fname: "Dhruv", lname: "Dabhi"),
            DataModel(fname: "Hiren", lname: "Sharma"),
            DataModel(fname: "Pujan", lname: "Shah"),
            DataModel(fname: "Chirag", lname: "Patel"),
            DataModel(fname: "Ashish", lname: "Patel"),
            DataModel(fname: "Binal", lname: "Patel"),
            DataModel(fname: "Simul", lname: "Patel"),
            DataModel(fname: "Hardik", lname: "Hingu")
        ]
    }
    private func searchBarSetup(){
        searchController.searchResultsUpdater = self
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
    }
    
}

extension ViewController: UISearchResultsUpdating{
    
    func updateSearchResults(for searchController: UISearchController) {
        // later
        guard let searchText = searchController.searchBar.text else { return }
        if searchText == ""{
            DataModelSetUP()
            
        }else{
            DataModelSetUP()
            arrData = arrData.filter{
                $0.fname.contains(searchText)
            }
            
        }
        
        tableView.reloadData()
    }
    
}



extension ViewController : UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel?.text = arrData[indexPath.row].fname
        cell.detailTextLabel?.text = arrData[indexPath.row].lname
        return cell
    }
    
}
